
def test():
	print "11001"